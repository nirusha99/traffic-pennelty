export const apiUrls = {
    authServiceApi:'http://localhost:8800/api/auth/',
    fineServiceApi:'http://localhost:8800/api/fine/',

}


