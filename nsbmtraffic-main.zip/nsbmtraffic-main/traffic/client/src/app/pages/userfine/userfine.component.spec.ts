import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UserfineComponent } from './userfine.component';

describe('UserfineComponent', () => {
  let component: UserfineComponent;
  let fixture: ComponentFixture<UserfineComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [UserfineComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(UserfineComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
