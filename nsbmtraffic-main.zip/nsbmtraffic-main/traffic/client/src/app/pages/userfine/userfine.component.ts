import { CommonModule } from '@angular/common';
import { Component, inject } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { AuthService } from '../../services/fine.service';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-userfine',
  standalone: true,
  imports: [CommonModule,ReactiveFormsModule],
  templateUrl: './userfine.component.html',
  styleUrl: './userfine.component.scss'
})
export default class UserfineComponent {

  fines: any[] = []; // Array to hold fine data

  constructor(private http: HttpClient) { }

  ngOnInit(): void {
    // Fetch fine data when the component initializes
    this.fetchFineData();
  }

  fetchFineData() {
    // Make HTTP GET request to fetch fine data
    this.http.get<any[]>('http://localhost:8800/api/fine/getall')
      .subscribe({
        next: (data) => {
          this.fines = data; // Assign fetched data to fines array
        },
        error: (error) => {
          console.error('Error fetching fine data:', error);
          // Handle error - Display error message or handle it as per your requirement
        }
      });
  }

}
