import { CommonModule } from '@angular/common';
import { Component, inject } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { AuthService } from '../../services/fine.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-adminfines',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './adminfines.component.html',
  styleUrl: './adminfines.component.scss'
})
export default class AdminfinesComponent {

  constructor(private fb: FormBuilder, private authService: AuthService, private router: Router) {}

  fineForm!: FormGroup;

  ngOnInit(): void {
    this.fineForm = this.fb.group({
      role: ['', Validators.required],
      username: ['', Validators.required],
      licenno:['', Validators.required],
      vehicleno: ['', Validators.required],
      vehicletype: ['', Validators.required],
      userid: ['', Validators.required] ,
      amount: ['', Validators.required] ,
      payed: ['', Validators.required] ,
      branch: ['', Validators.required] ,
      officer: ['', Validators.required] ,
      officerid: ['', Validators.required],
      isAdmin: [false] // Assuming isAdmin is a boolean field, you can adjust this as per your server-side requirements
    });
  }

  create() {
    this.authService.fineinsertService(this.fineForm.value)
      .subscribe({
        next: (res) => {
          alert("User Created");
          this.fineForm.reset();
          this.router.navigate(['login']);
        },
        error: (err) => {
          console.log(err);
          // Handle error here, such as displaying an error message to the user
        }
      });
  }
  navigateToUserFine() {
    this.router.navigate(['/userfine']);
  }
}
