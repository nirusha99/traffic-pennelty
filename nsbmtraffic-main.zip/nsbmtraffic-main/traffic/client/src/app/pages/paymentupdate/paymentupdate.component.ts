import { CommonModule } from '@angular/common';
import { Component, inject } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { AuthService } from '../../services/fine.service';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-paymentupdate',
  standalone: true,
  imports: [CommonModule,ReactiveFormsModule],
  templateUrl: './paymentupdate.component.html',
  styleUrl: './paymentupdate.component.scss'
})
export default class PaymentupdateComponent {

  constructor(private http: HttpClient) { }

  checkout(): void {
    // Make HTTP POST request to update fine details
    const updateData = {
      payed: 'true' // Update only the 'payed' field
    };

    const fineId = '6635fa7d050522132e502f09'; // Your fine ID
    this.http.post('http://localhost:8800/api/fine/update/' + fineId, updateData)
      .subscribe({
        next: (response) => {
          console.log('Fine details updated successfully:', response);
          // You can handle success here, such as showing a success message to the user
        },
        error: (error) => {
          console.error('Error updating fine details:', error);
          // Handle error - Display error message or handle it as per your requirement
        }
      });
  }
}
