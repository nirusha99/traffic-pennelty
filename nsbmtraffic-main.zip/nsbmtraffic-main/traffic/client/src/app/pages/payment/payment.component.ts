import { CommonModule } from '@angular/common';
import { Component, inject } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { AuthService } from '../../services/fine.service';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-payment',
  standalone: true,
  imports: [CommonModule,ReactiveFormsModule],
  templateUrl: './payment.component.html',
  styleUrl: './payment.component.scss'
})
export default class PaymentComponent {
  constructor(private http: HttpClient) { }

  checkout(): void {
    // Make HTTP POST request to update fine details
    const updateData = {
      payed: '1' // Update 'payed' column to '1'
    };

    const fineId = '66366190b1c3c960830f3d43'; // Your fine ID
    this.http.post('http://localhost:8800/api/fine/update/' + fineId, updateData)
      .subscribe({
        next: (response) => {
          console.log('Fine details updated successfully:', response);
          // You can handle success here, such as showing a success message to the user
        },
        error: (error) => {
          console.error('Error updating fine details:', error);
          // Handle error - Display error message or handle it as per your requirement
        }
      });
  }
}
