import { CommonModule } from '@angular/common';
import { Component, inject } from '@angular/core';
import { ReactiveFormsModule,FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AuthService } from '../../services/auth.service';
import { Router, RouterModule } from '@angular/router';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule,RouterModule],
  templateUrl: './login.component.html',
  styleUrl: './login.component.scss'
})
export default class LoginComponent {
  fb = inject(FormBuilder);
  authService = inject(AuthService);
  router = inject(Router);

  loginForm !: FormGroup;

  ngOnInit(): void {
    this.loginForm = this.fb.group({
      email: ['',Validators.compose([Validators.required,Validators.email])],
      password:['',Validators.required],
    })
  }

  login(){
    this.authService.loginService(this.loginForm.value)
    .subscribe({
      next: (res: any) => {
        alert("Login is Success!");
        this.loginForm.reset();
        // Parse response to determine user's role
        const userRoles = res.data.roles.map((role: any) => role.role);
        // Check if the user is an admin
        if (userRoles.includes('Admin')) {
          this.router.navigate(['/adminfine']);
        } else {
          this.router.navigate(['/home']);
        }
      },
      error: (err) => {
        console.log(err);
      }
    })
  }

}
