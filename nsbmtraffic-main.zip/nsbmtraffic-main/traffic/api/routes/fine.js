import express from 'express';
import Role from '../models/Fine.js';
import {createRole, updateRole, getAllRoles,deleteRole,getFineByUsername } from '../controllers/fine.controller.js';
import { verifyAdmin } from '../utils/verifyToken.js';

const router = express.Router();

//create a new role in DB
router.post('/create',createRole );

//Update role in DB
router.put('/update/:id',updateRole);

//get all the roles from DB
router.get('/getall',getAllRoles);

//delete role
router.delete('/deleterole/:id',deleteRole);

router.get('/getfine/:username', getFineByUsername);

export default router;
