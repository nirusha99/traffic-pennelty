import express from 'express';
import Role from '../models/Role.js';
import {createRole, updateRole, getAllRoles,deleteRole} from '../controllers/role.controller.js';
import { verifyAdmin } from '../utils/verifyToken.js';

const router = express.Router();

//create a new role in DB
router.post('/create',verifyAdmin,createRole );

//Update role in DB
router.put('/update/:id',verifyAdmin,updateRole);

//get all the roles from DB
router.get('/getall',getAllRoles);

//delete role
router.delete('/deleterole/:id',deleteRole);

export default router;
