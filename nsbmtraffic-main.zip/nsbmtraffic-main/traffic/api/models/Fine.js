import mongoose from 'mongoose';

const FineSchema = mongoose.Schema(
    {
        role:{
            type:String,
            required:true
        },
        username:{
            type:String,
            required:true
        },
        licenno:{
            type:String,
            required:true
        },
        vehicleno:{
            type:String,
            required:true
        },
        vehicletype:{
            type:String,
            required:true
        },
        userid:{
            type:String,
            required:true
        },
        username:{
            type:String,
            required:true
        },
        amount:{
            type:String,
            required:true
        },
        payed:{
            type:String,
            required:true
        },
        branch:{
            type:String,
            required:true
        },
        officer:{
            type:String,
            required:true
        },
        officerid:{
            type:String,
            required:true
        },
    },
    {
        timestamps: true
    }
);

export default mongoose.model("Fine",FineSchema);