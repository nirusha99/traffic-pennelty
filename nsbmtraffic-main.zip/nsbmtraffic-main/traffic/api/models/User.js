import mongoose,{Schema} from 'mongoose';


const UserSchema = mongoose.Schema(
    {
        firstName:{
            type:String,
            required:true
        },
        lastName:{
            type:String,
            required:true
        },
        username :{
            type:String,
            required:true,
            unique:true
        },
        email:{
            type:String,
            required:true,
            unique:true
        },
        password:{
            type:String,
            required:true
        },
        profileImage:{
            type:String,
            required:false,
            default:"https://img.freepik.com/free-vector/isolated-young-handsome-man-different-poses-white-background-illustration_632498-859.jpg?size=338&ext=jpg&ga=GA1.1.1700460183.1713312000&semt=ais"
        },
        isAdmin:{
            type:Boolean,
            default: false
        },
        roles:{
            type:[Schema.Types.ObjectId],
            required:true,
            ref:"Role"
        }
        

   
    },
    {
       timestamps:true 
    }
);

export default mongoose.model("User", UserSchema );;
